CREATE TABLE IF NOT EXISTS promotion_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_term_id UUID NOT NULL REFERENCES academic_terms(id),
    target_term_id UUID NOT NULL REFERENCES academic_terms(id),
    status VARCHAR(30) NOT NULL,
    total_siswa INTEGER NOT NULL DEFAULT 0,
    processed_siswa INTEGER NOT NULL DEFAULT 0,
    log JSONB,
    created_by UUID NOT NULL REFERENCES gurus(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at TIMESTAMPTZ
);
