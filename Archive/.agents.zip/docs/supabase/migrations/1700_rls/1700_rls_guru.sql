ALTER TABLE gurus ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Gurus can read all teacher profiles"
    ON gurus FOR SELECT
    USING (TRUE);

CREATE POLICY "Gurus can update their own profile"
    ON gurus FOR UPDATE
    USING (id = auth.uid());
