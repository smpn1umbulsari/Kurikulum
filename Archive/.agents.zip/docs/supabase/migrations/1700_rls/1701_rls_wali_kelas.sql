ALTER TABLE catatan_wali_kelas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Wali kelas can manage their own comments"
    ON catatan_wali_kelas FOR ALL
    USING (created_by = auth.uid());
