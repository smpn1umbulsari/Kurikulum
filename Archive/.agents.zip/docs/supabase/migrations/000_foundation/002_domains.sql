/* =========================================================
   SIKAD v4.5 - SECTION 002 - DOMAINS
   ========================================================= */
-- Core domain types placeholders (can be customized)
