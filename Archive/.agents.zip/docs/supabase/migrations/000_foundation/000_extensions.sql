/* =========================================================
   SIKAD v4.5 - SECTION 000 - EXTENSIONS
   ========================================================= */
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
