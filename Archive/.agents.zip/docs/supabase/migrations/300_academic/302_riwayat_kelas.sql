CREATE TABLE IF NOT EXISTS riwayat_kelas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    siswa_id UUID NOT NULL REFERENCES siswas(id) ON DELETE CASCADE,
    academic_term_id UUID NOT NULL REFERENCES academic_terms(id) ON DELETE CASCADE,
    kelas_real_id UUID REFERENCES kelas(id) ON DELETE CASCADE,
    kelas_dapo_id UUID REFERENCES kelas(id) ON DELETE CASCADE,
    tanggal_mulai DATE,
    tanggal_selesai DATE,
    status_keluar VARCHAR(30),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(academic_term_id, siswa_id)
);
