INSERT INTO roles (kode, nama) VALUES
('SUPERADMIN', 'Super Administrator'),
('ADMIN', 'Administrator Sekolah'),
('URUSAN', 'Urusan Kurikulum'),
('GURU', 'Guru Mata Pelajaran')
ON CONFLICT (kode) DO NOTHING;
