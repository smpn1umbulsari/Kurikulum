/* =========================================================
   SIKAD v4.5
   SECTION 001 - EXTENSIONS
   ========================================================= */

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";