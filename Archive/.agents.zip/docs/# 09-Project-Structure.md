# 09-Project-Structure.md

# PROJECT STRUCTURE

## SIKAD v4.5

Version: 4.5

Status: APPROVED

---

# TUJUAN

Menetapkan struktur proyek standar yang:

* Modular
* Scalable
* Offline First
* AI Agent Friendly
* Enterprise Maintainable

---

# ROOT STRUCTURE

```text
sikad-v4/

├── docs/
├── scripts/
├── supabase/
├── src/
├── public/
├── tests/
├── desktop/
├── .github/
├── package.json
├── vite.config.ts
├── tauri.conf.json
└── README.md
```

---

# DOCUMENTATION

```text
docs/

├── 00-Product-Architecture/
├── 01-PRD/
├── 02-TDD/
├── 03-Database/
├── 04-API/
├── 05-RLS/
├── 06-Migration/
├── 07-Deployment/
├── 08-Testing/
├── ADR/
└── CHANGELOG/
```

---

# SUPABASE

```text
supabase/

├── migrations/
├── seeds/
├── policies/
├── functions/
├── views/
├── triggers/
└── storage/
```

---

# SOURCE CODE

```text
src/

├── app/
├── modules/
├── shared/
├── infrastructure/
├── database/
├── services/
├── hooks/
├── routes/
├── store/
├── types/
└── utils/
```

---

# APP LAYER

```text
src/app/

├── providers/
├── layouts/
├── router/
├── theme/
└── config/
```

---

# MODULES

Feature Based Architecture

```text
src/modules/
```

---

# MODULE LIST

```text
authentication/
academic-term/
guru/
siswa/
kelas/
pembagian-mengajar/
tugas-tambahan/
assessment/
kehadiran/
rapor/
promotion/
graduation/
archive/
reporting/
export/
monitoring/
dashboard-kurikulum/
dashboard-kepsek/
settings/
```

---

# MODULE TEMPLATE

Contoh:

```text
assessment/

├── pages/
├── components/
├── services/
├── repositories/
├── hooks/
├── schemas/
├── types/
├── store/
└── tests/
```

---

# SHARED COMPONENTS

```text
src/shared/

├── components/
├── forms/
├── tables/
├── charts/
├── dialogs/
├── layout/
└── icons/
```

---

# INFRASTRUCTURE

```text
src/infrastructure/

├── supabase/
├── dexie/
├── realtime/
├── export/
├── monitoring/
└── auth/
```

---

# LOCAL DATABASE

```text
src/database/

├── dexie/
│   ├── schema.ts
│   ├── migrations/
│   └── sync/
│
└── repositories/
```

---

# SERVICES

Cross Module Services

```text
src/services/

├── sync/
├── analytics/
├── workload/
├── archive/
├── export/
└── notification/
```

---

# ROUTES

```text
src/routes/

├── public.tsx
├── protected.tsx
├── guru.tsx
├── kurikulum.tsx
├── admin.tsx
└── dashboard.tsx
```

---

# STATE MANAGEMENT

```text
src/store/

├── authStore.ts
├── appStore.ts
├── settingsStore.ts
└── syncStore.ts
```

Framework:

```text
Zustand
```

---

# TESTS

```text
tests/

├── unit/
├── integration/
├── e2e/
├── rls/
└── performance/
```

---

# DESKTOP

```text
desktop/

├── src-tauri/
├── icons/
├── installers/
└── release/
```

---

# GITHUB

```text
.github/

├── workflows/
│
├── ci.yml
├── staging.yml
└── production.yml
```

---

# FILE NAMING STANDARD

Components:

```text
PascalCase.tsx
```

---

Hooks:

```text
useSomething.ts
```

---

Services:

```text
somethingService.ts
```

---

Repositories:

```text
somethingRepository.ts
```

---

Stores:

```text
somethingStore.ts
```

---

# IMPORT RULES

Allowed:

```text
module
↓
shared
↓
infrastructure
```

---

Forbidden:

```text
module A
↓
module B
```

langsung.

Harus melalui service/repository.

---

# DEPENDENCY RULE

```text
UI
↓
Hooks
↓
Service
↓
Repository
↓
Supabase
```

---

# ACCEPTANCE CRITERIA

✓ Modular Structure

✓ Feature Based

✓ Offline Ready

✓ AI Agent Friendly

✓ Tauri Ready

✓ Testing Ready

✓ Supabase Ready

✓ Enterprise Scale Ready
