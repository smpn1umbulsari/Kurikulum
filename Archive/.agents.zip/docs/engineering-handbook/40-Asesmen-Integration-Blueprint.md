# 40. Asesmen Integration Blueprint — SIKAD v5.0

Dokumen ini merupakan cetak biru (blueprint) perencanaan integrasi konseptual untuk menyatukan modul Asesmen & Kepengawasan ke dalam sistem utama SIKAD v5.0. Cetak biru ini menjadi acuan resmi bagi pengembang ketika proses penulisan kode fisik sistem dimulai.

---

## 1. Arsitektur Integrasi Data (Database Level)

Untuk memastikan data master sekolah sinkron secara real-time dengan modul Asesmen, relasi database dirancang terintegrasi di tingkat skema Supabase (PostgreSQL).

```
  ┌─────────────────────────────────────────────────────────────┐
  │                        SIKAD Master                         │
  └──────────────────────────────┬──────────────────────────────┘
                                 │
         ┌───────────────────────┼───────────────────────┐
         ▼ 1-to-N                ▼ 1-to-N                ▼ 1-to-N
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│  academic_terms  │    │      gurus       │    │      siswas      │
└────────┬─────────┘    └────────┬─────────┘    └────────┬─────────┘
         │ 1                     │ N                     │ N
         ▼ N                     ▼ M (embedded JSONB)    ▼ M (embedded JSONB)
┌──────────────────────────────────────────────────────────────────┐
│                    kepangawasan (Asesmen DB)                     │
└──────────────────────────────────────────────────────────────────┘
```

### 1.1 Relasi Tabel Master & Transaksi
- **Academic Term (Semester)**: Kolom `term_id` pada tabel `kepangawasan` terikat sebagai Foreign Key ke tabel master `academic_terms(id)` di SIKAD Utama. Hal ini menjamin isolasi data jadwal ujian dan alokasi ruang per periode semester akademik.
- **Data Master Guru**: 
  - Kolom `matrix` (JSONB) pada `kepangawasan` merujuk ke ID dari master tabel `gurus(kode_guru)`.
  - Kolom `pembagian` (JSONB) menyimpan penugasan kode guru numerik anonim yang dipetakan ke ID asli guru di tabel master `gurus`.
- **Data Master Siswa & Rombel**:
  - Algoritma pembagian ruang siswa mengambil entri data secara dinamis dari tabel master `siswas` dengan filter `kelas` (rombel) berdasarkan opsi sumber kelas yang dipilih operator: `"bayangan"` (tabel `dapodik_rombel`) or `"asli"` (tabel `real_rombel`).

---

## 2. Arsitektur Modul & State (Application Level)

Rancangan struktur file dan pengelolaan state modul Asesmen diselaraskan dengan standar *Clean Architecture* dan *Zustand* di SIKAD Utama.

### 2.1 Struktur Folder Modul Asesmen
Konseptual pembagian modul diposisikan di bawah modul fitur `/src/modules/`:
```text
src/modules/assessment/
├── components/               # View / UI Components
│   ├── GradingSheet.tsx
│   ├── LevelPanel.tsx        # Representasi pembagian-ruang-view.js
│   └── RoomCard.tsx
├── services/                 # Business Logic & API Layer
│   └── assessmentService.ts  # Representasi pembagian-ruang-service.js
├── store/                    # Zustand State Store
│   └── useAssessmentStore.ts # Representasi pembagian-ruang-store.js
└── types/                    # TypeScript Type Definitions
    └── index.ts
```

### 2.2 Integrasi Zustand Store (Draft vs Applied)
Global Zustand store di `useAssessmentStore.ts` akan mewarisi logika draft dan applied state untuk mengisolasi perubahan form operator sebelum disimpan permanen:
```typescript
import { create } from 'zustand';

interface AssessmentState {
  // Applied State
  jumlahRuangUjian: number;
  asesmenLevelSettings: Record<string, LevelSettings>;
  
  // Draft State
  draftJumlahRuangUjian: number;
  draftAsesmenLevelSettings: Record<string, LevelSettings>;
  
  // Actions
  setDraftRoomCount: (count: number) => void;
  applySettings: (level: string) => void; // Menyalin draft ke applied & trigger sync
  loadFromLocalStorage: () => void;
}
```

---

## 3. Penyelarasan UI/UX & Design Tokens (Presentation Level)

- **Menu Sidebar Navigasi**: Menu "Administrasi Asesmen" diintegrasikan di bawah kelompok navigasi "Kurikulum" pada sidebar SIKAD Utama.
- **Tailwind CSS Adherence**: Kelas-kelas styling khusus modul Asesmen diselaraskan dengan utility class Tailwind CSS yang digunakan proyek utama:
  - `.app-panel--toolbar` diselaraskan menggunakan `sticky top-0 z-10 bg-background/80 backdrop-blur border-b border-border`.
  - `.asesmen-level-panel-disabled` diselaraskan dengan Tailwind utility `opacity-50 pointer-events-none select-none`.
- **SweetAlert2 (Swal) Unified**: Pemicuan notifikasi toast dan dialog konfirmasi menggunakan instance Swal terpusat dari core SIKAD untuk menjamin konsistensi warna tema (terutama penanganan dark mode).

---

## 4. Kebijakan Keamanan RLS Terpadu (Security Level)

Perlindungan data untuk guru pengawas dan pencegahan manipulasi jadwal asesmen diimplementasikan secara terintegrasi melalui PostgreSQL RLS di Supabase:

### 4.1 Aturan Otorisasi (RLS Policies)
- **Tabel `kepangawasan`**:
  - `ALL` actions (Insert/Update/Delete) hanya diizinkan bagi pengguna terautentikasi yang memiliki klaim JWT role `'admin'` atau `'superadmin'`.
  - `SELECT` diizinkan bagi operator sekolah dan guru pengawas.
- **Tabel `kepangawasan_kartu_guru`**:
  - `SELECT` dilindungi secara ketat agar guru pengawas hanya dapat mengakses baris data yang `kode_guru`-nya sesuai dengan ID guru dalam JWT token autentikasi mereka (`auth.jwt() ->> 'kode_guru'`).
  - `ALL` write actions didelegasikan eksklusif kepada proses sistem admin.

---

## 5. Rekomendasi Implementasi Bertahap (Roadmap)

Ketika proses penulisan kode sistem SIKAD v5.0 dimulai, berikut adalah langkah-langkah implementasi modul Asesmen secara bertahap:
1. **Fase 1 (Database Migration)**: Jalankan skrip pembuatan tabel `kepangawasan` dan `kepangawasan_kartu_guru` bersamaan dengan tabel master sekolah.
2. **Fase 2 (Core Logic & Service)**: Implementasikan kelas service `assessmentService.ts` dan buat unit test untuk memvalidasi algoritma alokasi otomatis `Balanced-Random` (memastikan tidak ada error saat pool guru kosong / starvation).
3. **Fase 3 (Zustand & LocalStorage)**: Buat state store `useAssessmentStore.ts` dan hubungkan mekanisme penyimpanan otomatis dengan debounce 1500ms.
4. **Fase 4 (UI Components)**: Buat komponen antarmuka panel level, tabel ketersediaan, dan kartu preview ruang menggunakan Tailwind CSS.
5. **Fase 5 (PDF & Excel Export)**: Pasang library `jspdf` / `pdfmake` dan `exceljs` di frontend untuk mengaktifkan cetak dokumen Tempel Kaca, Denah, dan ekspor XLSX.
