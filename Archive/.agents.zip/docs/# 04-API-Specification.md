# 04-API-Specification.md

# API SPECIFICATION

## SIKAD v4.5

Version: 4.5

Status: APPROVED

Architecture:

```text
React 19
↓
TanStack Query
↓
Service Layer
↓
Supabase Client
↓
PostgreSQL + RLS
```

---

# TUJUAN

Dokumen ini mendefinisikan standar API seluruh modul SIKAD v4.5.

---

# API PRINCIPLES

## Principle 1

Frontend tidak boleh mengakses database secara langsung.

Semua akses harus melalui:

```text
Repository Layer
↓
Service Layer
↓
Supabase
```

---

## Principle 2

Semua endpoint mengembalikan:

```typescript
{
 success:boolean;
 data:any;
 error?:string;
 meta?:object;
}
```

---

## Principle 3

Pagination wajib.

---

# STANDARD RESPONSE

## Success

```json
{
  "success": true,
  "data": {}
}
```

---

## Error

```json
{
  "success": false,
  "error": "DATA_NOT_FOUND"
}
```

---

# AUTHENTICATION API

Base:

```text
/api/auth
```

---

## Login

```http
POST /api/auth/login
```

Request:

```json
{
  "email":"guru@sikad.sch.id",
  "password":"*****"
}
```

---

Response:

```json
{
 "success":true,
 "data":{
   "user":{},
   "session":{}
 }
}
```

---

## Logout

```http
POST /api/auth/logout
```

---

## Current User

```http
GET /api/auth/me
```

---

# GURU API

Base:

```text
/api/gurus
```

---

## List Guru

```http
GET /api/gurus
```

Query:

```text
?page=1
&limit=20
&search=
```

---

## Detail Guru

```http
GET /api/gurus/{id}
```

---

## Create Guru

```http
POST /api/gurus
```

---

## Update Guru

```http
PUT /api/gurus/{id}
```

---

## Deactivate Guru

```http
PATCH /api/gurus/{id}/deactivate
```

---

# SISWA API

Base:

```text
/api/siswas
```

---

## List

```http
GET /api/siswas
```

Filters:

```text
kelas
tingkat
status
```

---

## Detail

```http
GET /api/siswas/{id}
```

---

## Create

```http
POST /api/siswas
```

---

## Update

```http
PUT /api/siswas/{id}
```

---

# ACADEMIC TERM API

Base:

```text
/api/academic-terms
```

---

## Active Term

```http
GET /api/academic-terms/active
```

---

## List

```http
GET /api/academic-terms
```

---

## Create

```http
POST /api/academic-terms
```

---

## Activate

```http
POST /api/academic-terms/{id}/activate
```

---

# KELAS API

Base:

```text
/api/kelas
```

---

## List

```http
GET /api/kelas
```

Filter:

```text
academic_term_id
tingkat
jenis
```

---

## Create

```http
POST /api/kelas
```

---

## Update

```http
PUT /api/kelas/{id}
```

---

## Assign Wali Kelas

```http
POST /api/kelas/{id}/wali-kelas
```

---

# PEMBAGIAN MENGAJAR API

Base:

```text
/api/pembagian-mengajar
```

---

## List

```http
GET /api/pembagian-mengajar
```

---

## Create

```http
POST /api/pembagian-mengajar
```

---

## Bulk Import

```http
POST /api/pembagian-mengajar/import
```

---

## Workload Summary

```http
GET /api/pembagian-mengajar/workload
```

---

# TUGAS TAMBAHAN API

Base:

```text
/api/tugas-tambahan
```

---

## List Assignment

```http
GET /api/tugas-tambahan
```

---

## Create Assignment

```http
POST /api/tugas-tambahan
```

---

## Workload

```http
GET /api/tugas-tambahan/workload
```

---

# ASSESSMENT API

Base:

```text
/api/assessments
```

---

## List

```http
GET /api/assessments
```

---

## Detail

```http
GET /api/assessments/{id}
```

---

## Create

```http
POST /api/assessments
```

Request:

```json
{
  "assessment_type_id":"",
  "pembagian_mengajar_id":"",
  "judul":"PH 1",
  "bobot":20
}
```

---

## Finalize

```http
POST /api/assessments/{id}/finalize
```

---

# NILAI API

Base:

```text
/api/assessment-details
```

---

## Bulk Save

```http
POST /api/assessment-details/bulk-save
```

Request:

```json
{
 "assessment_id":"",
 "details":[]
}
```

---

## Update Nilai

```http
PUT /api/assessment-details/{id}
```

---

# KEHADIRAN API

Base:

```text
/api/kehadiran
```

---

## Daily Attendance

```http
POST /api/kehadiran
```

---

## Bulk Attendance

```http
POST /api/kehadiran/bulk
```

---

## Summary

```http
GET /api/kehadiran/summary
```

---

# RAPOR API

Base:

```text
/api/rapor
```

---

## Generate

```http
POST /api/rapor/generate
```

---

## Finalize

```http
POST /api/rapor/finalize
```

---

## Reopen

```http
POST /api/rapor/reopen
```

---

## Get Snapshot

```http
GET /api/rapor/{id}
```

---

# PROMOTION API

Base:

```text
/api/promotion
```

---

## Preview

```http
POST /api/promotion/preview
```

---

## Execute

```http
POST /api/promotion/execute
```

---

## Status

```http
GET /api/promotion/{id}
```

---

# GRADUATION API

Base:

```text
/api/graduation
```

---

## Preview

```http
POST /api/graduation/preview
```

---

## Execute

```http
POST /api/graduation/execute
```

---

## Status

```http
GET /api/graduation/{id}
```

---

# REPORTING API

Base:

```text
/api/reports
```

---

## Academic Report

```http
GET /api/reports/academic
```

---

## Attendance Report

```http
GET /api/reports/attendance
```

---

## Teacher Workload

```http
GET /api/reports/workload
```

---

## Curriculum Report

```http
GET /api/reports/curriculum
```

---

# DASHBOARD API

## Kepala Sekolah

```http
GET /api/dashboard/kepsek
```

---

## Kurikulum

```http
GET /api/dashboard/kurikulum
```

---

# EXPORT API

Base:

```text
/api/export
```

---

## Excel

```http
POST /api/export/excel
```

---

## PDF

```http
POST /api/export/pdf
```

---

## ZIP

```http
POST /api/export/zip
```

---

## Download

```http
GET /api/export/{id}/download
```

---

# MONITORING API

Base:

```text
/api/monitoring
```

---

## System Health

```http
GET /api/monitoring/health
```

---

## Conflict Queue

```http
GET /api/monitoring/conflicts
```

---

## Resolve Conflict

```http
POST /api/monitoring/conflicts/{id}/resolve
```

---

# ARCHIVE API

Base:

```text
/api/archive
```

---

## Create Job

```http
POST /api/archive
```

---

## Status

```http
GET /api/archive/{id}
```

---

## Restore

```http
POST /api/archive/{id}/restore
```

---

# REALTIME CHANNELS

## Assessment

```text
assessment-updates
```

---

## Attendance

```text
attendance-updates
```

---

## Dashboard

```text
dashboard-updates
```

---

## Monitoring

```text
monitoring-updates
```

---

# API VERSIONING

Current:

```text
v1
```

Format:

```text
/api/v1/*
```

---

# RATE LIMIT

## Standard User

```text
100 requests/minute
```

---

## Admin

```text
300 requests/minute
```

---

# ERROR CODES

```text
AUTH_REQUIRED

ACCESS_DENIED

DATA_NOT_FOUND

VALIDATION_ERROR

DUPLICATE_DATA

ACADEMIC_TERM_LOCKED

RAPOR_FINALIZED

SYNC_CONFLICT

INTERNAL_SERVER_ERROR
```

---

# ACCEPTANCE CRITERIA

✓ RESTful Structure

✓ Versioned API

✓ Pagination Support

✓ Filtering Support

✓ Bulk Operations

✓ Realtime Ready

✓ RLS Compatible

✓ Offline Sync Compatible

✓ Audit Compatible

✓ Monitoring Compatible

---

# IMPLEMENTATION NOTE

Untuk SIKAD v4.5 yang menggunakan Supabase, layer API ini direalisasikan melalui:

```text
Repository Pattern
↓
Service Layer
↓
Supabase Client
```

bukan backend Express/NestJS terpisah.

Dengan demikian:

```text
React
↓
Service
↓
Supabase
```

tetap sederhana, tetapi seluruh kode aplikasi tetap mengikuti kontrak API yang konsisten dan mudah dimigrasikan ke backend dedicated di masa depan.
