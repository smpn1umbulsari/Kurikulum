# 12-AI-Agents.md

# AI AGENTS SPECIFICATION

## SIKAD v4.5

Version: 4.5

Status: APPROVED

---

# TUJUAN

Dokumen ini mendefinisikan pembagian tugas AI Agent agar pengembangan paralel tetap konsisten.

Target:

```text
Claude
Cline
Antigravity
Codex
GPT
```

---

# GLOBAL RULES

Semua agent wajib:

* Mengikuti PRD
* Mengikuti TDD
* Mengikuti ERD
* Mengikuti Coding Standards
* Tidak membuat struktur sendiri

---

# AGENT 1

## Database Architect

Role:

```text
Database
Migration
RLS
Performance
```

---

Ownership:

```text
supabase/

migrations/

policies/

views/

triggers/
```

---

Tasks:

```text
Schema

Indexes

Constraints

Views

Materialized Views

RLS Policies
```

---

Forbidden:

```text
React UI
```

---

# AGENT 2

## Backend Domain Engineer

Role:

```text
Business Logic
Service Layer
Repository Layer
```

---

Ownership:

```text
services/

repositories/
```

---

Tasks:

```text
Assessment Engine

Workload Engine

Promotion Engine

Graduation Engine

Archive Engine
```

---

Forbidden:

```text
Database Migration
```

---

# AGENT 3

## Frontend Application Engineer

Role:

```text
UI
Forms
Tables
Navigation
```

---

Ownership:

```text
pages/

components/

hooks/
```

---

Tasks:

```text
CRUD

Dashboard

Data Entry

User Experience
```

---

Forbidden:

```text
Business Logic
```

---

# AGENT 4

## Offline & Sync Engineer

Role:

```text
Dexie

Offline

Realtime

Conflict Resolution
```

---

Ownership:

```text
database/dexie

services/sync
```

---

Tasks:

```text
Sync Queue

Conflict Queue

Retry Engine

Offline Cache
```

---

Forbidden:

```text
Assessment Rules
```

---

# AGENT 5

## Reporting & Analytics Engineer

Role:

```text
Analytics

Dashboard

Reporting

Export
```

---

Ownership:

```text
reporting/

dashboard/

export/
```

---

Tasks:

```text
Analytics Snapshot

KPI Engine

PDF Export

Excel Export
```

---

# AGENT 6

## QA & Security Engineer

Role:

```text
Testing

Audit

Security
```

---

Ownership:

```text
tests/

security/
```

---

Tasks:

```text
Unit Test

Integration Test

RLS Validation

Performance Test

UAT Checklist
```

---

# DEVELOPMENT FLOW

```text
Database Agent
↓
Backend Agent
↓
Frontend Agent
↓
Sync Agent
↓
Analytics Agent
↓
QA Agent
```

---

# TASK HANDOFF FORMAT

Setiap agent wajib menghasilkan:

```markdown
## Completed

...

## Changed Files

...

## Dependencies

...

## Risks

...
```

---

# PULL REQUEST TEMPLATE

```markdown
Feature:

Files:

Database Impact:

RLS Impact:

Tests:

Risks:
```

---

# CONFLICT RESOLUTION

Jika dua agent mengubah:

```text
Entity Sama
```

maka prioritas:

```text
Database Architect
↓
Backend Engineer
↓
Frontend Engineer
```

---

# AGENT OUTPUT RULES

Setiap agent wajib:

✓ TypeScript Strict

✓ No Any

✓ Testable

✓ Modular

✓ RLS Compatible

✓ Offline Compatible

---

# CLAUDE CONFIG

Recommended Role:

```text
Backend Domain Engineer
```

Karena kuat pada:

```text
Architecture
Refactoring
Business Logic
```

---

# GPT CONFIG

Recommended Role:

```text
Database Architect
QA Engineer
```

Karena kuat pada:

```text
Schema
Documentation
Analysis
```

---

# CLINE CONFIG

Recommended Role:

```text
Frontend Engineer
Implementation Agent
```

Karena kuat pada:

```text
Code Generation
Multi-file Refactor
Execution
```

---

# ANTIGRAVITY CONFIG

Recommended Role:

```text
Full Stack Support Agent
```

Digunakan untuk:

```text
Refactor
Boilerplate
Utility
Testing
```

---

# FINAL TEAM STRUCTURE

```text
Database Architect

Backend Domain Engineer

Frontend Engineer

Offline Sync Engineer

Reporting Engineer

QA Engineer
```

---

# FINAL PRINCIPLE

AI Agent tidak boleh:

```text
Menebak Arsitektur
Menambah Tabel Baru
Mengubah Workflow Inti
Mengubah ERD
```

tanpa perubahan resmi pada:

```text
PRD
TDD
ERD
```

Seluruh implementasi harus tunduk pada spesifikasi SIKAD v4.5 sebagai single source of truth.
